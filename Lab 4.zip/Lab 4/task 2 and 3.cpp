#include <iostream>
#include <string>

using namespace std;

bool isValidExpression(const string& expr) {
    for (char ch : expr) {
        if (!isdigit(ch) && ch != '+' && ch != '-' && ch != '*' && ch != '/' && ch != '(' && ch != ')' && ch != ' ') {
            return false;
        }
    }
    return true;
}

bool areParenthesesBalanced(const string& expr) {
    int balance = 0;
    for (char ch : expr) {
        if (ch == '(') {
            balance++;
        } else if (ch == ')') {
            balance--;
            if (balance < 0) return false;
        }
    }
    return balance == 0;
}

bool isValidMathExpression(const string& expr) {
    if (!isValidExpression(expr)) {
        return false;
    }
    if (!areParenthesesBalanced(expr)) {
        return false;
    }

    for (size_t i = 0; i < expr.length(); ++i) {
        if ((i == 0 || i == expr.length() - 1) &&
            (expr[i] == '+' || expr[i] == '-' || expr[i] == '*' || expr[i] == '/')) {
            return false;
        }

        if (i > 0 && (expr[i] == '+' || expr[i] == '-' || expr[i] == '*' || expr[i] == '/') &&
            (expr[i-1] == '+' || expr[i-1] == '-' || expr[i-1] == '*' || expr[i-1] == '/')) {
            return false;
        }
    }
    return true;
}

int main() {
    string expr;
    cout << "Enter a mathematical expression: ";
    getline(cin, expr);

    if (isValidMathExpression(expr)) {
        cout << "The expression is valid and properly parenthesized." << endl;
    } else {
        cout << "The expression is either invalid or not properly parenthesized." << endl;
    }

    return 0;
}
