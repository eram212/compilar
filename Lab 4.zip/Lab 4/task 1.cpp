#include <iostream>
#include <string>
using namespace std;


string verbs[] = {"run", "eat", "go", "is", "are"};
string nouns[] = {"dog", "cat", "apple", "car", "tree"};
string pronouns[] = {"he", "she", "it", "they", "we"};
string conjunctions[] = {"and", "but", "or"};
string articles[] = {"a", "an", "the"};
string prepositions[] = {"in", "on", "at", "by"};


bool isInList(const string& word, string list[], int size) {
    for (int i = 0; i < size; i++) {
        if (word == list[i]) {
            return true;
        }
    }
    return false;
}


void printMatches(const string& label, string list[], int size, const string& sentence) {
    cout << label << ": ";
    string word = "";

    for (int i = 0; i <= sentence.length(); i++) {
        char c = sentence[i];


        if (c == ' ' || c == '.' || c == ',' || c == ';' || c == ':' || c == '\0') {

            if (!word.empty() && isInList(word, list, size)) {
                cout << word << " ";
            }
            word = "";
        } else {
            word += c;
        }
    }
    cout << endl;
}


int main() {

    cout << "Enter a sentence: ";
    string sentence;
    getline(cin, sentence);


    printMatches("Verbs", verbs, 5, sentence);
    printMatches("Nouns", nouns, 5, sentence);
    printMatches("Pronouns", pronouns, 5, sentence);
    printMatches("Conjunctions", conjunctions, 3, sentence);
    printMatches("Articles", articles, 3, sentence);
    printMatches("Prepositions", prepositions, 4, sentence);

    return 0;
}
