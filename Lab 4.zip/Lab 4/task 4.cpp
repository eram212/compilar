#include <iostream>
#include <string>
using namespace std;
int main() {
   string input;

   cout << "Enter a variable declaration: ";
   getline(cin, input);

   if (input.substr(0, 4) == "int " || input.substr(0, 7) == "double " || input.substr(0, 6) == "float " || input.substr(0, 5) == "char ") {
       cout << "Valid variable declaration.\n";
   } else {
       cout << "Invalid variable declaration.\n";
   }

   cout << "\nEnter a function declaration: ";
   getline(cin, input);

   bool isFunctionDeclaration = false;
   if ((input.substr(0, 4) == "int " || input.substr(0, 7) == "double " || input.substr(0, 6) == "float " || input.substr(0, 5) == "char ")) {
       for (int i = 4; i < input.size(); i++) {
           if (input[i] == '(' && input[i+1] == ')') {
               isFunctionDeclaration = true;
               break;
           }
       }
   }
   if (isFunctionDeclaration) {
       cout << "Valid function declaration.\n";
   } else {
       cout << "Invalid function declaration.\n";
   }

   cout << "\nEnter a function definition: ";
   getline(cin, input);

   bool isFunctionDefinition = false;
   if ((input.substr(0, 4) == "int " || input.substr(0, 7) == "double " || input.substr(0, 6) == "float " || input.substr(0, 5) == "char ")) {
       bool hasParentheses = false, hasBraces = false;
       for (int i = 0; i < input.size(); i++) {
           if (input[i] == '(' && input[i + 1] == ')') {
               hasParentheses = true;
           }
           if (input[i] == '{') {
               hasBraces = true;
           }
           if (input[i] == '}') {
               if (hasBraces) {
                   isFunctionDefinition = true;
                   break;
               }
           }
       }
   }
   if (isFunctionDefinition) {
       cout << "Valid function definition.\n";
   } else {
       cout << "Invalid function definition.\n";
   }
   return 0;
}
